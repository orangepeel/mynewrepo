# Custom Fonts

## Instructions

- Add custom fonts to your webpage.

- You can use [Google Fonts](https://fonts.google.com/) or another resource. Take a look at your options.

- Use one font for your headers and a different font for body text.

- Be creative, but remember the importance of typography to your design.

---

### Copyright

Trilogy Education Services © 2018. All Rights Reserved.
