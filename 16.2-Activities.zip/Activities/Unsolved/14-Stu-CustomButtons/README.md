# Custom Fonts

## Instructions

- Create 5 buttons. 

- You can use [w3 schools buttons lessons](https://www.w3schools.com/howto/tryit.asp?filename=tryhow_css_outline_buttons) or another resource. Take a look at your options.

- Create 5 HTML buttons and add 5 unique css classes.

- Be creative, change the element of the box model of defining the buttons. 

- Buttons need to have color, size, type, and interaction states.

---

### Copyright

Trilogy Education Services © 2018. All Rights Reserved.
