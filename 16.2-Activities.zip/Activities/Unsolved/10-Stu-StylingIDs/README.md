# Styling By ID

## Instructions

- Open up `id.html` and `style.css` within Visual Studio Code.

  - Add an ID selector that would set the `font-family` of an `h1` element as "Cursive".

  - Add in a second headline and style it with a new ID of your own creation.

- Open your `id.html` file in your browser to see the changes.

---

### Copyright

Trilogy Education Services © 2018. All Rights Reserved.
