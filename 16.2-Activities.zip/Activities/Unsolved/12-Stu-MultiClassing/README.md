# Multiple Classes

## Instructions

- There are four different headers within `multi.html`. Create three different CSS classes: `Mage`, `Warrior`, and `Rogue`.  Style the headers according to the following by adding multiple CSS classes to each element.

  - Mages are blue and have a "Cursive" font.

  - Rogues have an opacity of 50% and are italicized.

  - Warriors are much larger in font size - `50px` - and are bold.

  ---

### Copyright

Trilogy Education Services © 2018. All Rights Reserved.
