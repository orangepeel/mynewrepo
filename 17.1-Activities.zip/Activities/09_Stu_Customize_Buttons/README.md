# Pseudo-classes

- The goal of this activity is to use your new CSS skills and have fun while creating your own "suite" of button styles using basic CSS and pseudo-selectors.

## Instructions

- Open [Fancy Buttons](https://codepen.io/collection/bxdaH/) and encourage students to find a few buttons that your like.
- You re going to use these as inspiration for your new button "suite".
- Next open [customize.html](customize.html) and [style.css](style.css) in VS Code and your browser.
- Using your new skills, style your buttons.
- When you are done, take a screen shot and share it in Slack.
