# Pushing Your Buttons

- In this activity, you will be using the Bootstrap button docs to add four new buttons to your web page.

## Instructions

- Open [Unsolved/pushing.html](Unsolved/pushing.html) in VS Code.
- Visit the [Bootstrap Button Docs](https://getbootstrap.com/docs/4.1/components/buttons/).
- Copy four new buttons from the docs into the `pushing.html` file.
- Open `pushing.html` file in the browser to see the changes.
